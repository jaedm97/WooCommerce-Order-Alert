<?php
/*
	Plugin Name: WooCommerce Order Alert
	Plugin URI: https://pluginbazar.net/
	Description: This is a awesome solution for WooCommerce Order Alert.
	Version: 1.1.2
	Author: pluginbazar
	Author URI: https://pluginbazar.net/
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 


class WooCommerceOrderAlert{
	
	public function __construct(){
	
		$this->define_constants();
		$this->declare_classes();
		
		$this->loading_scripts();
		$this->loading_functions();
		
		// add_action( 'plugins_loaded', array( $this, 'load_textdomain' ));
	}
	
	public function load_textdomain() {

		load_plugin_textdomain( 'woc-order-alert', false, plugin_basename( dirname( __FILE__ ) ) . '/languages/' ); 
	}
	
	public function loading_functions(){
		
		require_once( plugin_dir_path( __FILE__ ) . 'includes/functions.php');
		require_once( plugin_dir_path( __FILE__ ) . 'includes/functions-settings.php');
		// require_once( plugin_dir_path( __FILE__ ) . 'includes/woa-settings-tab.php');
		// require_once( plugin_dir_path( __FILE__ ) . 'includes/class-settings.php');		
	}
	
	public function woa_admin_scripts(){

		wp_enqueue_script('jquery');
		
		wp_enqueue_script('woa-timer-js', plugins_url( '/assets/back/js/timer.jquery.js' , __FILE__ ) , array( 'jquery' ));
		wp_enqueue_script('woa-admin-js', plugins_url( '/assets/back/js/scripts.js' , __FILE__ ) , array( 'jquery' ));
		wp_localize_script('woa-admin-js', 'woa_ajax', array( 'woa_ajaxurl' => admin_url( 'admin-ajax.php')));

		wp_enqueue_style('woa_fontawesome', WOA_PLUGIN_URL.'assets/fonts/font-awesome.css');
		wp_enqueue_style('woa_admin_style', WOA_PLUGIN_URL.'assets/back/css/style.css');
	}
	
	public function loading_scripts(){
		
		add_action( 'admin_enqueue_scripts', 'wp_enqueue_media' );
		add_action( 'admin_enqueue_scripts', array( $this, 'woa_admin_scripts' ) );
	}
	
	public function declare_classes(){
		
		require_once( plugin_dir_path( __FILE__ ) . 'includes/classes/class-pick-settings.php');
	}
	
	public function define_constants(){
		
		define('WOA_PLUGIN_URL', WP_PLUGIN_URL . '/' . plugin_basename( dirname(__FILE__) ) . '/' );
		define('WOA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
		define('WOA_USER_TYPE', 'FREE' );
		define('WOA_TEXT_DOMAIN', 'woc-order-alert' );
	}

} new WooCommerceOrderAlert();