jQuery(document).ready(function($) {
	


	 
		var is_order = false;
		
		setTimeout(function(){
			$('.panel_loader').fadeOut();
			setTimeout(function(){
				$('.panel_main').fadeIn();
			}, 300);
			
		}, 300);
		
		var audioElement = document.createElement('audio');
		
		$(document).on('click', '.woa_start_checking', function()
		{
			$('.woa_timer').timer({
				duration: '3s',
				callback: function(){
					$('.woa_timer').timer('reset');
					if( !is_order ) {
						is_order = false;
						$('.woa_start_checking').click();
						
					}
				},
				repeat: true,
			});
			//return;
			
			
			$('.panel_main').fadeOut();
			setTimeout(function(){$('.panel_loader').fadeIn();}, 300);
			
						$.ajax(
							{
						type: 'POST',
						context: this,
						url:woa_ajax.woa_ajaxurl,
						data: {
							"action": "woa_ajax_check_new_order", 
						},
						success: function(data) {
							var a_html 	= JSON.parse(data);
							var count 	= a_html['count'];
							var audio 	= a_html['audio'];
							var html 	= a_html['html'];
							var woa_sound 	= a_html['woa_sound'];
							
							if ( count > 0 ) {
								is_order = true;
								$('.woa_start_checking').removeClass('woa_btn_center');
								$('.panel_main').append(html);
								setTimeout(function(){$('.woa_stop_alarm').fadeIn();}, 500);
								
								audioElement.setAttribute('src', audio);
								audioElement.setAttribute('autoplay', 'autoplay');
								$.get();
								audioElement.addEventListener("load", function() {audioElement.play();}, true);
								audioElement.addEventListener("ended", function(){audioElement.currentTime = 0;audioElement.play();});
								
								
								$('.panel_loader').fadeOut();
								setTimeout(function(){$('.panel_main').fadeIn();}, 300);
							
							} else is_order = false;
						},
						error: function(error) {
							alert(error);
						}
							});
							
							
			
			
			$('.panel_main ul.order_item_container').remove();
			$('.panel_header .woa_stop_alarm').fadeOut();
			
			//if( !is_order ) {
				
					
			//}
			
		})
		
		
		$(document).on('click', '.woa_stop_alarm', function()
		{
			//var audioElement = document.createElement('audio');
			//audioElement.setAttribute('src', audio);
			//audioElement.setAttribute('autoplay', 'autoplay');
			//$.get();
			audioElement.pause();
			audioElement.currentTime = 0;
			//audioElement.addEventListener("ended", function(){audioElement.currentTime = 0;audioElement.play();});
		})
		
		$(document).on('click', '.woa_start_checking', function()
		{
			
		})
		
	});

	
	
	