<?php	
/*
* @Author 		Pluginbazar
* Copyright: 	2015 Pluginbazar
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 

?>

<div class="woa-panel-checker">

	<div class="pc-section pc-section-checker">
		
		<div class="pc-section-title">Check New Order</div>
		<div class="pc-checker-loading"><i class="fa fa-cog" aria-hidden="true"></i></div>
		<div class="pc-checker-buttons">
			<div class="button"><span>Start Checking</span> &nbsp <i class="fa fa-play" aria-hidden="true"></i></div>
			<div class="button"><span>Stop Checking</span> &nbsp <i class="fa fa-stop" aria-hidden="true"></i></div>
			<div class="button"><span>Mute</span> &nbsp <i class="fa fa-volume-off" aria-hidden="true"></i></div>
		</div>
		
	</div>
	
	
	<div class="pc-section pc-section-orderlist">
		
		<div class="pc-section-title">New Order List</div>
		<div class="pc-orders-list">
			<div class="single-order">
				<div class="meta order-id">#220</div>
				<div class="meta order-customer">Guest</div>
				<div class="meta order-amount">200 $</div>
				<div class="meta order-date"><span>November 7, 2017</span><br><span>12 Minutes ago</span></div>
				<div class="meta order-action button"><i class="fa fa-external-link" aria-hidden="true"></i></div>
			</div>
		</div>
		
	</div>
	
	

</div>