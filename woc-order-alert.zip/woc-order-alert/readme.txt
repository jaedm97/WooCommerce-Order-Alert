=== Woocommerce Order Alert ===
	Contributors: jaedm97,pluginbazar
	Donate link: http://pluginbazar.net/donate
	Tags: woc-order-alert, WooCommerce Order Alert, Order Alert, Order alarm, Woocommerce Order Alarm, Alam, Alert, WooCommerce Alert, WooCommerce Alarm
	Requires at least: 3.8
	Tested up to: 4.7
	Stable tag: 1.1.2
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	You can get alert with strong customizable alarm when an order arrive.

== Description ==

Using this plugin you can get alert with strong volume alarm in your computer or any other device when a new order is come. No need to refresh it manually all the time.  
This will save your time and extra man power. By this your order management will be SMART.
	

### Woocommerce Order Alert by pluginbazar - Jaed Mosharraf
* [Live Demo &raquo;](http://pluginbazar.net/demo-woc-order-alert/)
* [Get Woocommerce Open Close Pro &raquo;](http://pluginbazar.net/product/woocommerce-order-alert/)
* [Back Admin Look &raquo;](http://pluginbazar.net/demo-woc-open-close/wp-admin/)

	Username: demo
	Password: demo
	
	
== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin settings via WordPress Dashboard and find "<strong>Woocommerce Order Alert</strong>" activate it.<br />

== Screenshots ==

1. screenshot-1.png

2. screenshot-2.png

3. screenshot-3.png

4. screenshot-4.png

== Changelog ==

	= 1.0.0 =
    * 10/13/2016 Initial release.
	
	= 1.0.0 =
    * 07/15/2016 Fixes some problems.
	
	