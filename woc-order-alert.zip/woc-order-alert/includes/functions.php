<?php
/*
* @Author 		Jaed Mosharraf
* Copyright: 	2015 Jaed Mosharraf
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 

	
	function woa_ajax_check_new_order()
	{
		$html = array();
	
		$wp_query = new WP_Query(
			array (
				'post_type' => 'shop_order',
				'post_status' => 'wc-processing',
			) );
		
		$html['count'] 	= $wp_query->found_posts;
		
		$items_html 	= '
		<ul class="order_item_container">
			<li class="single_item">
				<ul class="single_item_inner">
					<li class="order_title woa_width_100 center">Order Title</li>
					<li class="order_items woa_width_100 center">Total Item</li>
					<li class="order_price woa_width_100 center">Total Price</li>
					<li class="shipping_address woa_width_180 center">Shipping Address</li>
					<li class="shipping_address woa_width_180 center">Date / Time</li>
				</ul>
			</li>';
		
		if ( $wp_query->have_posts() ) :
			while ( $wp_query->have_posts() ) : $wp_query->the_post();	
				
				global $wpdb;
				global $woocommerce;
				
				$order 		= new WC_Order( get_the_ID() );
				$price 		= $order->get_formatted_order_total();
				$item_count = $order->get_item_count();
				$address	= $order->get_formatted_shipping_address();

				$items_html .=  '
				<li class="single_item">
					<ul class="single_item_inner">
						<li class="order_title woa_width_100"><a href="'.admin_url().'post.php?post='.get_the_ID().'&action=edit">Order-'.get_the_ID().'</a></li>
						<li class="order_items woa_width_100 center">'.$item_count.'</li>
						<li class="order_price woa_width_100 center">'.$price.'</li>
						<li class="shipping_address woa_width_180">'.$address.'</li>
						<li class="shipping_address woa_width_180 center">'.get_the_date() .' at '.get_the_time().'</li>
					</ul>
				</li>';
				
			endwhile;wp_reset_query();
		endif;
		
		$items_html  .= '</ul>';
		$html['html'] =  $items_html;
		
		$html['audio'] = WOA_PLUGIN_URL.'resources/back/audio/10001.mp3';
		
		echo json_encode($html);
		die();
	}
	add_action('wp_ajax_woa_ajax_check_new_order', 'woa_ajax_check_new_order');
	add_action('wp_ajax_nopriv_woa_ajax_check_new_order', 'woa_ajax_check_new_order');
	
	

	
/* 
Code for: Admin Notices
*/	


function woa_admin_notice__error() {
	
	$class 		= 'notice notice-error';
	$message 	= 'These features are not functional in free version !';
	$buy_link 	= 'http://pluginbazar.ml/product/woocommerce-order-alert/';
	
	printf('<div class="%1$s"><p>%2$s <a href="%3$s" target="_blank"> %4$s</a></p></div>', $class, $message, $buy_link, 'Purchase Now'); 
}
// add_action( 'admin_notices', 'woa_admin_notice__error' );

	

/* 
Code for: Panel Checker
*/

function action_woa_panel_checker_function(){
	
	include WOA_PLUGIN_DIR . "templates/admin/panel-checker.php";
}
add_action( 'woa_panel_checker', 'action_woa_panel_checker_function' );


