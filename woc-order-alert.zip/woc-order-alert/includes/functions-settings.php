<?php

/*
* @Author 		pickplugins
* Copyright: 	2015 pickplugins
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 


$woa_panel_checker = array(
	'page_nav' => __( 'Checker', WOA_TEXT_DOMAIN ),
	'page_settings' => array(),
);

// $woa_panel_ = array(
	// 'page_nav' => __( 'Checker', WOA_TEXT_DOMAIN ),
	// 'page_settings' => array(),
// );



$args = array(
	'add_in_menu' => true,
	'menu_type' => 'submenu',
	'menu_title' => __( 'Order Alert', WOA_TEXT_DOMAIN ),
	'page_title' => __( 'WooCommerce Order Alert', WOA_TEXT_DOMAIN ), 
	'menu_page_title' => __( 'Control System', WOA_TEXT_DOMAIN ),
	'capability' => "manage_options",
	'menu_slug' => "woc-order-alert",
	'parent_slug' => "woocommerce",
	'pages' => array(
		'woa_panel_checker' => $woa_panel_checker,
	),
);

$Pick_settings = new Pick_settings( $args );



/* 
function pickplugins_wl_get_wishlist_pages(){
	
	$pages_array = array( '' => __( 'Select Page', WOA_TEXT_DOMAIN ) );
	
	foreach( get_pages() as $page ):
		$pages_array[ $page->ID ] = $page->post_title;
	endforeach;
	
	return $pages_array;
}

function pickplugins_wl_get_share_platforms(){
	
	$platforms = array();
	foreach( pickplugins_wl_get_social_platforms() as $key => $platform ) $platforms[ $key ] = $platform['title'];
	return $platforms;
}
 */


