<?php

class WC_Settings_Tab_Demo {

    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50 );
        add_action( 'woocommerce_settings_tabs_settings_order_alert', __CLASS__ . '::settings_tab' );
        add_action( 'woocommerce_update_options_settings_order_alert', __CLASS__ . '::update_settings' );
    }
	
    public static function add_settings_tab( $settings_tabs ) {
        $settings_tabs['settings_order_alert'] = __( 'Order Alert', 'woa' );
        return $settings_tabs;
    }
    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
    }
    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
    }

    public static function get_settings() {

        $settings = array(
            'section_title' => array(
                'name'     	=> __( 'WooCommerce Order Alert Settings', 'woa' ),
                'type'     	=> 'title',
                'desc'     	=> '',
                'id'       	=> 'wc_settings_order_alert_section'
            ),
			
			'woa_sound'		=> array(
                'name' 		=> __( 'Alert Sound', 'woa' ),
                'type' 		=> 'select',
				'options' 	=> array(
					'10001' => __( 'Default', 'woa' ),
					'10002' => __( 'Nuclear Alarm', 'woa' ),
					'10003' => __( 'Emergency', 'woa' ),
					
				),
                'desc' 		=> __( 'Select your Preferred Sound', 'woa' ),
				'desc_tip' 	=>  true,
                'id'   		=> 'wc_settings_woa_sound'
            ),
			
			'woa_sound_url' => array(
                'name' 		=> __( 'Custom Alert Sound URL', 'woa' ),
                'type' 		=> 'text',
                'desc' 		=> __( 'Add the URL of your Custom Sound File', 'woa' ),
                'placeholder'=> __( 'http://----.mp3', 'woa' ),
				'desc_tip' 	=> true,
                'id'   		=> 'wc_settings_woa_sound_url'
            ),
			
			
            'section_end' 	=> array(
                 'type' 	=> 'sectionend',
                 'id' 		=> 'wc_settings_order_alert_section_end'
            ),
			
			
        );
		
		

        return apply_filters( 'wc_settings_order_alert_settings', $settings );
    }

}

WC_Settings_Tab_Demo::init();