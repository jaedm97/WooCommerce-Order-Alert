<?php

/*
* @Author 		Jaed Mosharraf
* Copyright: 	2015 Jaed Mosharraf
*/

if ( ! defined('ABSPATH')) exit;  // if direct access

class class_woa_settings{

	public function __construct(){
		
		add_action('admin_menu', array( $this, 'woa_menu_init' ));
		
	}

	public function woa_order_alert(){
		include('menu/order-alert.php');
		//return 'Jaed';
	}
	
	public function woa_menu_analytics(){	
		include('menu/analytics.php');
	}

	public function woa_menu_init() {
		//add_submenu_page('edit.php?post_type=woa', __('Analytics','woa'), __('Analytics','woa'), 'manage_options', 'woa_analytics', array( $this, 'woa_menu_analytics' ));	
		add_submenu_page('woocommerce', __('Order Alert','woa'), __('Order Alert','woa'), 'manage_options', 'woa_order_alert', array( $this, 'woa_order_alert' ));	
	}
}
	
new class_woa_settings();